//Bolinha
let xBolinha = 300;
let yBolinha = 200;
let diametro = 25;
let raio = diametro / 2

//Movimento Bolinha
let velocidadeXBolinha = 6;
let velocidadeYBolinha = 6;

//Raquete
let xRaquete = 10;
let yRaquete = 160;
let comprimentoRaquete = 10;
let alturaRaquete = 80;

function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(0);
  circle(xBolinha, yBolinha, diametro);
  velocidadeBolinha();
  movimentoBolinhaBorda();
  rect(xRaquete, yRaquete, comprimentoRaquete, alturaRaquete);
  colisaoRaquete();
  movimentoRaquete();
}

function velocidadeBolinha(){
  xBolinha += velocidadeXBolinha;
  yBolinha += velocidadeYBolinha;
}

function movimentoBolinhaBorda(){
    if (xBolinha + raio > width || xBolinha - raio < 0){
      velocidadeXBolinha *= -1
      }
  
  if (yBolinha + raio > height || yBolinha - raio < 0){
      velocidadeYBolinha *= -1
      } 
}

function colisaoRaquete(){
  if (xBolinha - raio < xRaquete + comprimentoRaquete && yBolinha - raio < yRaquete + alturaRaquete && yBolinha + raio > yRaquete){
      velocidadeXBolinha *= -1
      }
}

function movimentoRaquete(){
  if (keyIsDown(UP_ARROW)){
      yRaquete -= 10
      }
  if (keyIsDown(DOWN_ARROW)){
      yRaquete += 10
  }
}